function myapp(){
  console.log("myapp javascript loaded")
}
