This is a XRSH example package with an polyglot '.env' (autoenv) entrypoint.
It can be loaded in various ways into [your own instance of] https://xrsh.isvery.ninja:

* copy the zip in a filemanager to your clipboard, and paste it into your XRSH-tab
* drag-drop the zip from a filemanager to your XRSH-tab
* download the zip, and type 'upload' in XRSH to import it

Currently, '.env' links to 'bin/app.sh', but there are also other scriptinglanguages it could link to as well (see bin-folder).

Basically, an XRSH package is just a zip with an autoenv entrypoint, which gets extracted to /root/{zipname} that's it!
